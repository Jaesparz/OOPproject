/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;
import java.util.Scanner;
import controlador.*;




/**
 *
 * @author Jair Palaguachi
 * Clase Vista Usuario junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones
 */
public class VistaMenuPrincipal {
    
    public static Scanner scanner = new Scanner(System.in);
     ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaMenuPrincipal(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    
    
    // Métodos para mostrar el Menú Principal
    public void mostrarMenuPrincipal() {
        System.out.println("Menú Principal:");
        System.out.println("1. Administrar categorías");
        System.out.println("2. Administrar ingresos");
        System.out.println("3. Administrar gastos");
        System.out.println("4. Administrar cuentas por cobrar");
        System.out.println("5. Administrar cuentas por pagar");
        System.out.println("6. Administrar cuentas bancarias");
        System.out.println("7. Administrar inversiones");
        System.out.println("8. Administrar personas y bancos");
        System.out.println("9. Reportes");
        System.out.println("10. Proyección de gastos");
        System.out.println("11. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    
    
    
    

    

    
    
    
    
    
    
    
    

 
    

    
}
