/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package vista;
import java.time.LocalDate;
import java.util.List;
import modelo.*;


import controlador.ControladorFinanzas;
import java.util.Scanner;

/**
 *
 * @author Jair Palaguachi
 * Clase VistaIngresos junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de Ingresos
 */
public class VistaIngresos {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;
    
    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaIngresos(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar ingresos
    public void administrarIngresos() {
        
        mostrarIngresos();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Ingresos:");
            System.out.println("1. Registrar Ingreso");
            System.out.println("2. Eliminar ingreso");
            System.out.println("3. Finalizar ingreso");
            System.out.println("4. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    registrarIngreso();
                    break;
                case 2:
                    eliminarIngreso();
                    break;
                case 3:
                    finalizarIngreso();
                    break;
                case 4:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarIngresos() {
        List<Transaccion> ingresos = controlador.getIngresos();
        System.out.printf("%-10s%-16s%-12s%-15s%-18s%-12s%-12s\n", "Código", "Fecha inicio", "Categoría", "Valor Neto", "Descripción", "Fecha fin", "Repetición");
        for (Transaccion ingreso : ingresos) {
            System.out.println(ingreso);
        }
    }

    public void registrarIngreso() {
        
        
        System.out.print("Categoría: ");
        String nombreCategoria = scanner.nextLine();
        VistaCategoria vc= new VistaCategoria(controlador);
        Categoria categoria = vc.buscarCategoria(nombreCategoria, TipoCategoria.INGRESO);
        if(categoria == null){
            System.out.println("Categoria no existente");
            return;
        }
        System.out.print("Valor: ");
        double valor = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Fecha inicio (YYYY-MM-DD): ");
        LocalDate fechaInicio = LocalDate.parse(scanner.nextLine());
        System.out.print("Repetición (sin repeticion/mensual): ");
        String repeticion = scanner.nextLine();
        System.out.print("Fecha fin (YYYY-MM-DD) (opcional/Enter): ");
        String fechaFinStr = scanner.nextLine();
        LocalDate fechaFin = fechaFinStr.isEmpty() ? null : LocalDate.parse(fechaFinStr);
        
        if (repeticion.equalsIgnoreCase("sin repeticion")){
            controlador.registrarIngreso(fechaInicio, categoria, valor, descripcion, fechaFin, Repeticion.SINREPETICION);
            
          
        }else if (repeticion.equalsIgnoreCase("mensual")){
            controlador.registrarIngreso(fechaInicio, categoria, valor, descripcion, fechaFin, Repeticion.MES);
          
        }
        
        System.out.println("Ingreso agregado correctamente.");

        
    }

    public void eliminarIngreso() {
        System.out.print("Código del ingreso a eliminar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.println("ADVERTENCIA: al eliminar no se tomará en cuenta para los reportes de saldos");
        System.out.println("¿Está seguro de que desea eliminar el Ingreso ? (si/no)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("si")){
           controlador.eliminarIngreso(codigo);
        } else {
        System.out.println("Eliminación cancelada.");
    }
       System.out.println("Ingreso eliminado correctamente."); 
    }

    public void finalizarIngreso() { 
        System.out.print("Código del ingreso a finalizar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha fin (YYYY-MM-DD): ");
        LocalDate fechaFin = LocalDate.parse(scanner.nextLine());
        controlador.finalizarIngreso(codigo, fechaFin);
        System.out.println("Ingreso finalizado correctamente.");
    }
    
    
   
    
    
    
  
    
}
