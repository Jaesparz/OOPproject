/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import modelo.CuentasPorPagar;
import modelo.Entidad;


/**
 *
 * @author Jair Palaguachi
 * Clase VistaCuentasPorPagar junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de CuentasPorPagar
 */
public class VistaCuentasPorPagar {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaCuentasPorPagar(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar cuentas por pagar
    public void administrarCuentasPorPagar() {
        mostrarCuentasPorPagar();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Cuentas por Pagar:");
            
            System.out.println("1. Registrar deuda");
            System.out.println("2. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    registrarDeuda();
                    break;
                case 2:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarCuentasPorPagar() {
        List<CuentasPorPagar> cuentasPorPagar = controlador.getCuentasPorPagar();
        System.out.printf("%-8s%-15s%-15s%-20s%-18s%-20s%-20s%-20s%-20s%-12s\n", "Código", "Deudor", "Valor", "Descripción", "Fecha préstamo","Cuotas préstamo","FechaInicioPago","FechaFinPago","Cedula/Ruc","Interés");
        for (CuentasPorPagar cuenta : cuentasPorPagar) {
            System.out.println(cuenta);
        }
    }

    public void registrarDeuda() {
        System.out.print("La deuda es de una Persona o un Banco? (P/B): ");
        String tipo = scanner.nextLine();
        System.out.print("CI/RUC del acreedor: ");
        String ci = scanner.nextLine();
        VistaPersonasBancos vpb= new VistaPersonasBancos(controlador);
        Entidad acreedor = vpb.buscarPersonaBanco(ci);
        if (acreedor == null){
            if (tipo.equalsIgnoreCase("P")){
                System.out.println("Persona no existente");
                System.out.println("Registre a la persona primero:");
                vpb.registrarPersonaBanco("P");
                
            } else{
                System.out.println("Banco no existente");
                System.out.println("Registre al banco primero:");
                vpb.registrarPersonaBanco("B");
                
            }
            
        } else{
            System.out.println(acreedor.getNombre());
        
        System.out.print("Valor de la deuda: ");
        double valor = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Fecha del préstamo (YYYY-MM-DD): ");
        LocalDate fechaPrestamo = LocalDate.parse(scanner.nextLine());
        System.out.print("Cuota mensual: ");
        double cuota = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Interés mensual: ");
        double interes = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha inicio de pago (YYYY-MM-DD): ");
        LocalDate fechaInicioPago = LocalDate.parse(scanner.nextLine());
        System.out.print("Fecha fin de pago (YYYY-MM-DD): ");
        LocalDate fechaFinPago = LocalDate.parse(scanner.nextLine());

        controlador.registrarDeuda(acreedor, valor, descripcion, fechaPrestamo, cuota , fechaInicioPago, fechaFinPago,ci,interes);
        System.out.println("Deuda agregada correctamente.");
        }
        
        }
    
    
    
    
    
    
    
    
    
    
}
