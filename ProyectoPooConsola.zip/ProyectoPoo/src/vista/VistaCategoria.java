/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package vista;
import java.util.Scanner;
import java.util.List;
import modelo.*;
import controlador.*;



/**
 *
 * @author Jair Palaguachi
 * Clase VistaCategoria junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de categoria
 */
public class VistaCategoria {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;
    
    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaCategoria(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar Categorias
    public void administrarCategorias() { 
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Categorías:");
            mostrarCategorias();
            System.out.println("1. Agregar Categoría");
            System.out.println("2. Eliminar Categoría");
            System.out.println("3. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    agregarCategoria();
                    break;
                case 2:
                    eliminarCategoria();
                    break;
                case 3:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarCategorias() { 
        
        List<Categoria> categorias = controlador.getCategorias();
        System.out.println("Categorías de Ingresos:");
        for (Categoria categoria : categorias) {
            if (categoria.getTipo().equals(TipoCategoria.INGRESO)) {
                System.out.println(categoria.getNombre());
            }
        }

        System.out.println("Categorías de Gastos:");
        for (Categoria categoria : categorias) {
            if (categoria.getTipo().equals(TipoCategoria.GASTO)) {
                System.out.println(categoria.getNombre());
            }
        }
    }

    public void agregarCategoria() { 
        System.out.print("Tipo de Categoría (Ingresos/Gastos): ");
        String tipo = scanner.nextLine();
        System.out.print("Nombre de categoría: ");
        String nombre = scanner.nextLine();
        
        if (tipo.equalsIgnoreCase("Ingresos")){
            
            boolean b= controlador.agregarCategoria(nombre, TipoCategoria.INGRESO);
            if (b== true){
                System.out.println("Categoría de Ingreso agregada correctamente.");
            }
            
           
            
        } else if (tipo.equalsIgnoreCase("Gastos")){
            
            boolean b= controlador.agregarCategoria(nombre, TipoCategoria.GASTO);
            if (b== true){
                System.out.println("Categoría de Gasto agregada correctamente.");
            }
            
            
        }
        
    }
    
    public void eliminarCategoria() { 
        System.out.print("Tipo de Categoría (Ingresos/Gastos): ");
        String tipo = scanner.nextLine();
        System.out.print("Nombre de categoría a eliminar: ");
        String nombre = scanner.nextLine();
        System.out.println("¿Está seguro de que desea eliminar la categoría de Ingreso '" + nombre + "'? (si/no)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("si")){
            for (Categoria categoria : controlador.getCategorias()){
                if (tipo.equalsIgnoreCase("Ingresos") && categoria.getNombre().equalsIgnoreCase(nombre)){
                    controlador.eliminarCategoria(nombre, TipoCategoria.INGRESO);
                    System.out.println("Categoría de Ingreso eliminada.");
                    return;
                    
                } else if (tipo.equalsIgnoreCase("Gastos") && categoria.getNombre().equalsIgnoreCase(nombre)){
                    controlador.eliminarCategoria(nombre, TipoCategoria.GASTO);
                    System.out.println("Categoría de Gasto eliminada.");
                    return;
                }      
              }
               System.out.println("La categoría no existe.");
          
        } else{
        System.out.println("Eliminación cancelada.");
    }
        
    }
    
    
     /**
     * @param nombre String que identifica el nombre de una categoria
     * @param tipo String que identifica el tipo de una categoria
     * @return el método retorna una instancia de la clase Categoria o null
     * 
     */            
// Método para buscar instancias de la clase Categoria
    public  Categoria buscarCategoria(String nombre, TipoCategoria tipo) {
        List<Categoria> categorias = controlador.getCategorias();
        for (Categoria categoria : categorias) {
            if (categoria.getNombre().equals(nombre) && categoria.getTipo().equals(tipo)) {
                return categoria;
            }
        }
        return null;
    }
    
    
    
    
    
}
