/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;
import controlador.ControladorFinanzas;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import modelo.*;
/**
 *
 * @author Jair Palaguachi
 * Clase VistaGastos junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de Gastos
 */
public class VistaGastos {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;
    
    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaGastos(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar gastos
    public void administrarGastos() { 
        mostrarGastos();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Gastos:");
            
            System.out.println("1. Registrar Gasto");
            System.out.println("2. Eliminar Gasto");
            System.out.println("3. Finalizar Gasto");
            System.out.println("4. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    registrarGasto();
                    break;
                case 2:
                    eliminarGasto();
                    break;
                case 3:
                    finalizarGasto();
                    break;
                case 4:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarGastos() {
        List<Transaccion> gastos = controlador.getGastos();
        System.out.printf("%-10s%-16s%-15s%-14s%-18s%-12s%-12s\n", "Código", "Fecha inicio", "Categoría", "Valor", "Descripción", "Fecha fin", "Repetición");
        for (Transaccion gasto : gastos) {
            System.out.println(gasto);
        }
    }

    public void registrarGasto() {
        
        System.out.print("Categoría: ");
        String nombreCategoria = scanner.nextLine();
        VistaCategoria vc= new VistaCategoria(controlador);
        Categoria categoria = vc.buscarCategoria(nombreCategoria, TipoCategoria.GASTO);
        if(categoria == null){
            System.out.println("Categoria no existente");
            return;
        }
        System.out.print("Valor: ");
        double valor = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Fecha inicio (YYYY-MM-DD): ");
        LocalDate fechaInicio = LocalDate.parse(scanner.nextLine());
        System.out.print("Repetición (sin repeticion/mensual): ");
        String repeticion = scanner.nextLine();
        System.out.print("Fecha fin (YYYY-MM-DD) (opcional/Enter): ");
        String fechaFinStr = scanner.nextLine();
        LocalDate fechaFin = fechaFinStr.isEmpty() ? null : LocalDate.parse(fechaFinStr);
        
        if (repeticion.equalsIgnoreCase("sin repeticion")){
            controlador.registrarGasto(fechaInicio, categoria, valor, descripcion, fechaFin, Repeticion.SINREPETICION);
            
          
        }else if (repeticion.equalsIgnoreCase("mensual")){
            controlador.registrarGasto(fechaInicio, categoria, valor, descripcion, fechaFin, Repeticion.MES);
          
        }
        System.out.println("Gasto agregado correctamente.");
 
    }

    public void eliminarGasto() {
        System.out.print("Código del gasto a eliminar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.println("ADVERTENCIA: al eliminar no se tomará en cuenta para los reportes de saldos");
        System.out.println("¿Está seguro de que desea eliminar el Gasto ? (si/no)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("si")){
           controlador.eliminarGasto(codigo);
        } else {
        System.out.println("Eliminación cancelada.");
    }
       System.out.println("Gasto eliminado correctamente.");  
    }

    public void finalizarGasto() {
        System.out.print("Código del gasto a finalizar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha fin (YYYY-MM-DD): ");
        LocalDate fechaFin = LocalDate.parse(scanner.nextLine());
        controlador.finalizarGasto(codigo, fechaFin);
        System.out.println("Gasto finalizado correctamente."); 
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
