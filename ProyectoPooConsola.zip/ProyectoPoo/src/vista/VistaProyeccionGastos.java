/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import modelo.Proyeccion;
import modelo.Transaccion;

/**
 *
 * @author Jair Palaguachi
 * Clase VistaProyeccionGastos junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de Proyeccion de Gastos
 */
public class VistaProyeccionGastos {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaProyeccionGastos(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Método para proyección de gastos
    public void proyeccionGastos() {
        System.out.println("Gastos en los últimos tres meses:");
        Date fechaActual = new Date();
        double suma=0;
        int cantidadGastos=0;
       
        for(Transaccion i : controlador.getGastos()){
         if(i.getFechaInicio().getMonthValue()> fechaActual.getMonth()-3){
             System.out.println(i.getFechaInicio().getMonth());
              System.out.println(" Categoria             Valor");
            
              System.out.println(i.getCategoria().getNombre()+ "              " +i.getValor());
              
              suma+=i.getValor();
              cantidadGastos+=1;
              controlador.registrarProyeccion(i.getCategoria().getNombre(), i.getValor());
            }
         }
         ArrayList<Proyeccion> proyecciones = controlador.getProyecciones();
         
         ArrayList<String> categoriasProyeccion=new ArrayList<>();
         ArrayList<Double> valoresProyeccion=new ArrayList<>();
         
         for (Proyeccion proyeccion:proyecciones){
              if (!categoriasProyeccion.contains(proyeccion.getCategoria())){
               categoriasProyeccion.add(proyeccion.getCategoria());
               valoresProyeccion.add(proyeccion.getValor());
               
              } else {
               int posicion= categoriasProyeccion.indexOf(proyeccion.getCategoria());
               double elemento= valoresProyeccion.get(posicion);
               valoresProyeccion.set(posicion, elemento+=proyeccion.getValor());
             }
        }
            
        System.out.println("Proyección de gastos para el próximo mes:");
         
           for(int i=0;i<categoriasProyeccion.size();i++){
               System.out.println(categoriasProyeccion.get(i)+ "              " + valoresProyeccion.get(i)/3); // asumiendo que el usuario tuvo el mismo gasto en los tres meses
           }
              System.out.println("Valor Total");
              System.out.println(suma/cantidadGastos);
        
    }
    
}
