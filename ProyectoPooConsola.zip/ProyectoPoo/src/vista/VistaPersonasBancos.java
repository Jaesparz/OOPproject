/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.util.List;
import java.util.Scanner;
import modelo.Banco;
import modelo.Entidad;
import modelo.Persona;


/**
 *
 * @author USUARIO
 */
public class VistaPersonasBancos {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaPersonasBancos(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar personas y bancos
    public void administrarPersonasYBancos() {
        mostrarPersonas();
        mostrarBancos();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Personas y Bancos:");
            
            System.out.println("1. Registrar Persona/Banco");
            System.out.println("2. Eliminar Persona/Banco");
            System.out.println("3. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    System.out.println("Desea registrar una Persona o un Banco? (P/B)");
                    String tipo = scanner.nextLine();
                    registrarPersonaBanco(tipo);
                    break;
                case 2:
                    eliminarPersonaBanco();
                    break;
                case 3:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarPersonas() {
        List<Persona> personas = controlador.getPersonas();
        System.out.println("Personas Registradas:");
        for (Persona persona : personas) {
            System.out.println(persona);
        }
    }

    public void mostrarBancos() {
        List<Banco> bancos = controlador.getBancos();
        System.out.println("Bancos Registrados:");
        for (Banco banco : bancos) {
            System.out.println(banco);
        }
    }
    
    /**
     * @param tipo String que sirve para identificar si se desa registrar una persona o banco 
     */
    // Métodos para registrar/eliminar Personas o Bancos
    public void registrarPersonaBanco(String tipo) {
        if (tipo.equalsIgnoreCase("P")){
            System.out.print("CI: ");
            String ci = scanner.nextLine();
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Dirección: ");
            String direccion = scanner.nextLine();

        controlador.registrarPersona(ci, nombre, telefono, direccion);
        System.out.println("Persona registrada correctamente.");

        } else if(tipo.equalsIgnoreCase("B")){
            System.out.print("RUC: ");
            String ci = scanner.nextLine();
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Dirección: ");
            String direccion = scanner.nextLine();
            System.out.print("NombreOficialCredito: ");
            String nombreOficialCredito = scanner.nextLine();
            System.out.print("TeléfonoOficialCredito: ");
            String telefonoOficialCredito = scanner.nextLine();

        controlador.registrarBanco(ci, nombre,telefono,direccion, nombreOficialCredito,telefonoOficialCredito);
        System.out.println("Banco registrado correctamente.");
        }
        
       
    }
    
    public void eliminarPersonaBanco() {
        System.out.print("Ingrese el identificador (cédula o ruc) de la persona o banco a eliminar: ");
        String codigo = scanner.nextLine();
        Entidad entidad=buscarPersonaBanco(codigo);
        System.out.println(entidad);
        //scanner.nextLine(); // Consumir el salto de línea
        System.out.println("ADVERTENCIA: se eliminaran todos los registros asociados (cuentas por cobrar, deudas o inversiones)");
        System.out.println("¿Está seguro de que desea eliminar el Gasto ? (si/no)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("si")){
           controlador.eliminarPersonaBanco(codigo);
        } else {
        System.out.println("Eliminación cancelada.");
    }
    System.out.println("Persona/Banco eliminado correctamente."); 
    }

    /**
     * @param ci String que identifica el ruc/cedula de una persona/banco
     * @return el método retorna una instancia de la clase Persona, una instancia de la clase Banco o null
     * 
     */ 
    public Entidad buscarPersonaBanco(String ci) {
        List<Persona> personas = controlador.getPersonas();
        for (Persona persona : personas) {
            if (persona.getRucId().equals(ci)) {
                return persona;
            }
        }
        List<Banco> bancos = controlador.getBancos();
        for (Banco banco : bancos) {
            if (banco.getRucId().equals(ci)) {
                return banco;
            }
        }
        return null;
    }
    
    /**
     * @param ci String que identifica la cedula de una persona
     * @return el método retorna una instancia de la clase Persona o null
     * 
     */ 
    public Persona buscarPersona(String ci) {
        List<Persona> personas = controlador.getPersonas();
        for (Persona persona : personas) {
            if (persona.getRucId().equals(ci)) {
                return persona;
            }
        }
        return null;
    }
    
    /**
     * @param ci String que identifica el ruc de un banco
     * @return  el método retorna una instancia de la clase Banco o null
     * 
     */ 
    public Banco buscarBanco(String ci) {
        List<Banco> bancos = controlador.getBancos();
        for (Banco banco : bancos) {
            if (banco.getRucId().equals(ci)) {
                return banco;
            }
        }
        return null;
    }
}
