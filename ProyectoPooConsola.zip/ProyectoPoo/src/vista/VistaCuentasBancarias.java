/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import modelo.Banco;
import modelo.CuentaBancaria;
import modelo.TipoCuenta;


/**
 *
 * @author Jair Palaguachi
 * Clase VistaCuentasBancarias junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de CuentaBancaria
 */
public class VistaCuentasBancarias {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaCuentasBancarias(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar cuentas bancarias
    public void administrarCuentasBancarias() {
        mostrarCuentasBancarias();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Cuentas Bancarias:");
            
            System.out.println("1. Registrar cuenta bancaria");
            System.out.println("2. Eliminar cuenta bancaria");
            System.out.println("3. Cerrar cuenta bancaria");
            System.out.println("4. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    registrarCuentaBancaria();
                    break;
                case 2:
                    eliminarCuentaBancaria();
                    break;
                case 3:
                    cerrarCuentaBancaria();
                    break;
                case 4:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }


    public void mostrarCuentasBancarias() {
        List<CuentaBancaria> cuentasBancarias = controlador.getCuentasBancarias();
        System.out.printf("%-8s%-23s%-13s%-15s%-20s%-20s%-20s%-20s\n", "Código", "Entidad Bancaria", "Numero", "Tipo", "Fecha Apertura","Saldo","Interés","Fecha Cierre");
        for (CuentaBancaria cuenta : cuentasBancarias) {
            System.out.println(cuenta);
        }
    }

    public void registrarCuentaBancaria() {
        System.out.print("CI del banco: ");
        String ci = scanner.nextLine();
        VistaPersonasBancos vpb= new VistaPersonasBancos(controlador);
        Banco banco = vpb.buscarBanco(ci);
        if(banco == null){
            System.out.println("Banco no existente");
            return;
        }
        System.out.print("Número de cuenta: ");
        String numero = scanner.nextLine();
        System.out.print("Tipo de cuenta (AHORRO/CORRIENTE): ");
        String tipo = scanner.nextLine();
        System.out.print("Fecha de apertura (YYYY-MM-DD): ");
        LocalDate fechaApertura = LocalDate.parse(scanner.nextLine());
        System.out.print("Saldo inicial: ");
        double saldo = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Interés mensual: ");
        double interesMensual = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha fin (YYYY-MM-DD) (opcional/Enter): ");
        String fechaFinStr = scanner.nextLine();
        LocalDate fechaCierre = fechaFinStr.isEmpty() ? null : LocalDate.parse(fechaFinStr);
        
        if (tipo.equalsIgnoreCase("AHORRO")){
            controlador.registrarCuentaBancaria(banco, numero, TipoCuenta.AHORRO, fechaApertura, saldo, interesMensual,fechaCierre );
            
        } else if (tipo.equalsIgnoreCase("CORRIENTE")){
            controlador.registrarCuentaBancaria(banco, numero, TipoCuenta.CORRIENTE, fechaApertura, saldo, interesMensual,fechaCierre );
        }
        System.out.println("Cuenta Bancaria agregada correctamente.");
    }

    public void eliminarCuentaBancaria() {
        System.out.print("Código de la cuenta bancaria a eliminar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.println("ADVERTENCIA: al eliminar no se tomará en cuenta para los reportes de saldos");
        System.out.println("¿Está seguro de que desea eliminar el Gasto ? (si/no)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("si")){
           controlador.eliminarCuentaBancaria(codigo);
        } else {
        System.out.println("Eliminación cancelada.");
        
    }
        System.out.println("Cuenta Bancaria eliminada correctamente."); 
    }
    

    public void cerrarCuentaBancaria() {
        System.out.print("Código de la cuenta bancaria a cerrar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha de cierre (YYYY-MM-DD): ");
        LocalDate fechaCierre = LocalDate.parse(scanner.nextLine());
        controlador.cerrarCuentaBancaria(codigo, fechaCierre);
        System.out.println("Cuenta Bancaria cerrada correctamente."); 
    }
    
    
    
    
}
