/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import modelo.CuentasPorCobrar;
import modelo.Persona;


/**
 *
 * @author Jair Palaguachi
 * Clase VistaCuentasPorCobrar junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de CuentasPorCobrar
 */
public class VistaCuentasPorCobrar {
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaCuentasPorCobrar(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    
    // Métodos para administrar cuentas por cobrar
    public void administrarCuentasPorCobrar() {
        mostrarCuentasPorCobrar();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Cuentas por Cobrar:");
            
            System.out.println("1. Registrar préstamo");
            System.out.println("2. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    registrarPrestamo();
                    break;
                case 2:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarCuentasPorCobrar() {
        List<CuentasPorCobrar> cuentasPorCobrar = controlador.getCuentasPorCobrar();
         System.out.printf("%-8s%-15s%-15s%-20s%-18s%-20s%-20s%-20s%-20s\n", "Código", "Deudor", "Valor", "Descripción", "Fecha préstamo","Cuotas préstamo","FechaInicioPago","FechaFinPago","Cedula");
        for (CuentasPorCobrar cuenta : cuentasPorCobrar) {
            System.out.println(cuenta);
        }
    }

    public void registrarPrestamo() {
        System.out.print("CI del deudor: ");
        String ci = scanner.nextLine();
        VistaPersonasBancos vpb= new VistaPersonasBancos(controlador);
        Persona deudor = vpb.buscarPersona(ci);
        if (deudor == null){
            System.out.println("Persona no existente");
            System.out.println("Registre a la persona primero:");
            vpb.registrarPersonaBanco("P");
            
            
        } else{
            System.out.println(deudor.getNombre());
        
        System.out.print("Valor del préstamo: ");
        double valor = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Fecha del préstamo (YYYY-MM-DD): ");
        LocalDate fechaPrestamo = LocalDate.parse(scanner.nextLine());
        System.out.print("Cuota mensual: ");
        double cuota = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha inicio de pago (YYYY-MM-DD): ");
        LocalDate fechaInicioPago = LocalDate.parse(scanner.nextLine());
        System.out.print("Fecha fin de pago (YYYY-MM-DD): ");
        LocalDate fechaFinPago = LocalDate.parse(scanner.nextLine());

        controlador.registrarPrestamo(deudor, valor, descripcion, fechaPrestamo, cuota, fechaInicioPago, fechaFinPago,ci);
        System.out.println("Préstamo agregado correctamente.");
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
