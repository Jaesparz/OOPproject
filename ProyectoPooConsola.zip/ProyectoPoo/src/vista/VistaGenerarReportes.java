/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.util.Scanner;
import modelo.Transaccion;


/**
 *
 * @author Jair Palaguachi
 * Clase VistaGenerarReportes junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de Reportes
 */
public class VistaGenerarReportes {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaGenerarReportes(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para generar reportes
    public void generarReportes() {
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Generar Reportes:");
            System.out.println("1. Reporte de ingresos");
            System.out.println("2. Reporte de gastos");
            System.out.println("3. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    generarReporteIngresos();
                    break;
                case 2:
                    generarReporteGastos();
                    break;
                case 3:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
    
    // Métodos para generar reportes Ingresos
    public void generarReporteIngresos(){
        boolean regresar = false;
        while (!regresar) {
            
            System.out.println("Seleccionar Periodo:");
            System.out.println("1. Mes actual");
            System.out.println("2. Año");
            System.out.println("3. Regresar Menú Principal");
            
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    generarReporteIngresosMes();
                    break;
                case 2:
                    generarReporteIngresosAño();
                    break;
                case 3:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void generarReporteIngresosMes() {
        System.out.println("Reporte de Ingresos:");
        System.out.println("Ingrese el mes que desee (numero): ");
        int mes = scanner.nextInt();

        double valorT = 0;

        System.out.println("Categoria                   Valor");
        

        for(Transaccion i : controlador.getIngresos()){

          if(i.getFechaInicio().getMonthValue()==mes){

            System.out.println(i.getCategoria().getNombre()+ "                     " +i.getValor());

            valorT += i.getValor();
            
          }

        }
        System.out.println("Total                       " + valorT);
        
    }
    
    public void generarReporteIngresosAño() {
        System.out.println("Reporte de Ingresos:");
        System.out.println("Ingrese el año que desee: ");
        int anio = scanner.nextInt();
        
        double valorT2 = 0;

        System.out.println("Ingrese el mes actual: ");
        int mes = scanner.nextInt();

          for(Transaccion i : controlador.getIngresos()){

          if(i.getFechaInicio().getYear() == anio && i.getFechaInicio().getMonthValue()<= mes){
              System.out.println(i.getFechaInicio().getMonth());
              System.out.println(" Categoria             Valor");
            
              System.out.println(i.getCategoria().getNombre()+ "              " +i.getValor());
              valorT2 += i.getValor();
              
            }

          }
          System.out.println("Total                       " + valorT2);
        
    }
    
    

    // Métodos para generar reportes Gastos
    public void generarReporteGastos(){
        boolean regresar = false;
        while (!regresar) {
            
            System.out.println("Seleccionar Periodo:");
            System.out.println("1. Mes actual");
            System.out.println("2. Año");
            System.out.println("3. Regresar Menú Principal");
            
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    generarReporteGastosMes();
                    break;
                case 2:
                    generarReporteGastosAño();
                    break;
                case 3:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
    public void generarReporteGastosMes() {
        System.out.println("Reporte de Gastos:");
        System.out.println("Ingrese el mes que desee (numero): ");
        int mes = scanner.nextInt();

        double valorT = 0;

        System.out.println("Categoria                   Valor");
        

        for(Transaccion i : controlador.getGastos()){

          if(i.getFechaInicio().getMonthValue()==mes){

            System.out.println(i.getCategoria().getNombre()+ "                     " +i.getValor());

            valorT += i.getValor();
            
          }

        }
        System.out.println("Total                       " + valorT);
    }
    
    public void generarReporteGastosAño(){
        System.out.println("Reporte de Gastos:");
        System.out.println("Ingrese el año que desee: ");
        int anio = scanner.nextInt();
        
        double valorT2 = 0;

        System.out.println("Ingrese el mes actual: ");
        int mes = scanner.nextInt();

          for(Transaccion i : controlador.getGastos()){

          if(i.getFechaInicio().getYear() == anio && i.getFechaInicio().getMonthValue()<= mes){
              System.out.println(i.getFechaInicio().getMonth());
              System.out.println(" Categoria             Valor");
            
              System.out.println(i.getCategoria().getNombre()+ "              " +i.getValor());
              valorT2 += i.getValor();
              
            }

          }
          System.out.println("Total                       " + valorT2);
    }
    
}
