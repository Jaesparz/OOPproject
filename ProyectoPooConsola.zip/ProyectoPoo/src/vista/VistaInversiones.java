/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorFinanzas;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import modelo.Banco;
import modelo.Inversion;


/**
 *
 * @author Jair Palaguachi
 * Clase VistaInversiones junto con sus métodos que se muestran por pantalla al usuario dependiendo de las opciones de Inversion
 */
public class VistaInversiones {
    
    public static Scanner scanner = new Scanner(System.in);
    ControladorFinanzas controlador;

    /**
     * @param controlador instancia de la Clase ControladorFinanzas 
     */
    public VistaInversiones(ControladorFinanzas controlador) {
        this.controlador = controlador;
    }
    
    // Métodos para administrar inversiones
    public void administrarInversiones() {
        mostrarInversiones();
        boolean regresar = false;
        while (!regresar) {
            System.out.println("Administrar Inversiones:");
            
            System.out.println("1. Registrar inversión");
            System.out.println("2. Eliminar inversión");
            System.out.println("3. Regresar Menú principal");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    registrarInversion();
                    break;
                case 2:
                    eliminarInversion();
                    break;
                case 3:
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    public void mostrarInversiones() {
        List<Inversion> inversiones = controlador.getInversiones();
        System.out.printf("%-10s%-23s%-20s%-20s%-20s%-20s\n", "Código", "Entidad Bancaria", "Fecha Apertura","Cantidad","Interés Mensual","Fecha Finalizacíon");
        for (Inversion inversion : inversiones) {
            System.out.println(inversion);
        }
    }

    public void registrarInversion() {
        System.out.print("CI del banco: ");
        String ci = scanner.nextLine();
        VistaPersonasBancos vpb= new VistaPersonasBancos(controlador);
        Banco banco = vpb.buscarBanco(ci);
        if(banco == null){
            System.out.println("Banco no existente");
            return;
        }
        System.out.print("Fecha de apertura (YYYY-MM-DD): ");
        LocalDate fechaApertura = LocalDate.parse(scanner.nextLine());
        System.out.print("Cantidad invertida: ");
        double cantidad = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Interés mensual: ");
        double interesMensual = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Fecha de finalización (YYYY-MM-DD): ");
        LocalDate fechaFinalizacion = LocalDate.parse(scanner.nextLine());

        controlador.registrarInversion(banco, fechaApertura, cantidad, interesMensual, fechaFinalizacion);
        System.out.println("Inversión agregada correctamente.");
    }

    public void eliminarInversion() {
        System.out.print("Código de la inversión a eliminar: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.println("ADVERTENCIA: al eliminar no se tomará en cuenta para los reportes de saldos");
        System.out.println("¿Está seguro de que desea eliminar el Gasto ? (si/no)");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("si")){
           controlador.eliminarInversion(codigo);
        } else {
        System.out.println("Eliminación cancelada.");
        
    }
        System.out.println("Inversión eliminada correctamente."); 
    }

    
    
    
}

