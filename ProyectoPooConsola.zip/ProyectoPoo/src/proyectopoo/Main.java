/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectopoo;
import java.util.Scanner;
import controlador.*;
import vista.*;
/**
 *
 * @author Jair Palaguachi,Julio Llerena,Josue Esparza,Jairo Rodriguez
 * Clase main donde se desarrolla el programa principal con sus opciones
 */
public class Main {
    public static Scanner scanner = new Scanner(System.in);
    
    /**
     * @param args metodo main del proyecto
     */
    public static void main(String[] args) {
        
        ControladorFinanzas controlador = new ControladorFinanzas();
        VistaMenuPrincipal vista = new VistaMenuPrincipal(controlador);
        VistaCategoria vc= new VistaCategoria(controlador);
        VistaIngresos vi= new VistaIngresos(controlador);
        VistaGastos vg= new VistaGastos(controlador);
        VistaCuentasPorCobrar vcpc= new VistaCuentasPorCobrar(controlador);
        VistaCuentasPorPagar vcpp= new VistaCuentasPorPagar(controlador);
        VistaCuentasBancarias vcb= new VistaCuentasBancarias(controlador);
        VistaInversiones vin= new VistaInversiones(controlador);
        VistaPersonasBancos vpb= new VistaPersonasBancos(controlador);
        VistaGenerarReportes vgr= new VistaGenerarReportes(controlador);
        VistaProyeccionGastos vpg= new VistaProyeccionGastos(controlador);
                
        boolean salir = false;
        while (!salir) {
            vista.mostrarMenuPrincipal();
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    vc.administrarCategorias();
                    break;
                case 2:
                    vi.administrarIngresos();
                    break;
                case 3:
                    vg.administrarGastos();
                    break;
                case 4:
                    vcpc.administrarCuentasPorCobrar();
                    break;
                case 5:
                    vcpp.administrarCuentasPorPagar();
                    break;
                case 6:
                    vcb.administrarCuentasBancarias();
                    break;
                case 7:
                    vin.administrarInversiones();
                    break;
                case 8:
                    vpb.administrarPersonasYBancos();
                    break;
                case 9:
                    vgr.generarReportes();
                    break;
                case 10:
                    vpg.proyeccionGastos();
                    break;
                case 11:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }
    

    
}


    

