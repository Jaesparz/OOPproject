package com.example.proyect;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.Categoria;

public class MainActivity extends AppCompatActivity {
    private Button btnAgregar;
    private RegistrarCategoria registrarCategoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtener el botón del menú
        Button btnMenu1 = findViewById(R.id.btn1);

        // Agregar listener al botón
        btnMenu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Iniciar la actividad ControladorAdmCategoria
                Intent intent = new Intent(MainActivity.this, ControladorAdmCategoria.class);
                startActivity(intent);
            }
        });

        // Otros botones y funcionalidades
    }

    public void admcuentasporCobrar(View v) {
        Intent intent = new Intent(this, ControladorCuentasporCobrar.class);
        startActivity(intent);
    }

    public void salirApp(View v) {
        finish();
    }

    public void admcuentasporPagar(View v) {
        Intent intent = new Intent(this, ControladorCuentasPorPagar.class);
        startActivity(intent);
    }

    public void iniciarAdmCategoria(View v) {
        Intent intent = new Intent(this, ControladorAdmCategoria.class);
        startActivity(intent);
    }


    public void atras(View view) {
        try {
            finish(); // Cierra la actividad actual y regresa al menú principal
            // Otra opción: startActivity(new Intent(AdministrarCategoriasActivity.this, MenuPrincipalActivity.class));
        } catch (Exception e) {
            Log.e("Error", "Error al presionar el botón Atrás: " + e.getMessage());
            Toast.makeText(this, "Error al regresar al menú principal", Toast.LENGTH_SHORT).show();
        }
    }
}


