package com.example.proyect;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import modelo.CuentasPorCobrar;
import modelo.CuentasPorPagar;
import modelo.Entidad;
import modelo.Persona;

public class registrarcpp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registrarcpp);

    }

    private EditText etcpp1, etcpp2, etcpp3, etcpp4, etcpp5, etcpp6, etcpp7, etcpp8;

    public void guardarcpp(View v){
        etcpp1=findViewById(R.id.etcpp1);
        etcpp2=findViewById(R.id.etcpp2);
        etcpp3=findViewById(R.id.etcpp3);
        etcpp4=findViewById(R.id.etcpp4);
        etcpp5=findViewById(R.id.etcpp5);
        etcpp6=findViewById(R.id.etcpp6);
        etcpp7=findViewById(R.id.etcpp7);
        etcpp8=findViewById(R.id.etcpp8);
        String acreedor=etcpp1.getText().toString();
        String valor=etcpp2.getText().toString();
        String inter=etcpp3.getText().toString();
        String descripcion=etcpp4.getText().toString();
        String fechaPrestamo=etcpp5.getText().toString();
        String cuota=etcpp6.getText().toString();
        String fechaInicioPago=etcpp7.getText().toString();
        String fechaFinPago=etcpp8.getText().toString();
        ArrayList<Persona> personas= Persona.cargarPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        Log.d("ProyectoPoo", personas.toString());
        for (Entidad p : personas) {
            if (p.getRucId().equals(acreedor)) {
                registrarDeuda(p, Double.parseDouble(valor), descripcion, LocalDate.parse(fechaPrestamo), Double.parseDouble(cuota), LocalDate.parse(fechaInicioPago), LocalDate.parse(fechaFinPago), p.getRucId(),Double.parseDouble(inter));
                Toast.makeText(getApplicationContext(),"Deuda registrado", Toast.LENGTH_SHORT).show();
                finish();

            } else{
                Toast.makeText(getApplicationContext(),"Persona no encontrada", Toast.LENGTH_SHORT).show();
                finish();
                return;

            }
        }

    }
    public void registrarDeuda(Entidad acreedor, double valor, String descripcion, LocalDate fechaPrestamo, double cuota, LocalDate fechaInicioPago, LocalDate fechaFinPago,String RucId,double interes) {
        ArrayList<CuentasPorPagar> cuentasPorPagar = CuentasPorPagar.cargarCuentasporPagar(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        cuentasPorPagar.add(new CuentasPorPagar(acreedor, valor, descripcion, fechaPrestamo, cuota, fechaInicioPago, fechaFinPago,RucId, interes));
        File f = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), CuentasPorPagar.nomArchivo);
        //se escribe la lista serializada
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            //os.writeObject(personas);
            os.writeObject(cuentasPorPagar);

        } catch (IOException e) {
            //quizas lanzar una excepcion personalizada
            //throw new Exception(e.getMessage());
            System.out.println("Error en la serealización");
        }
    }

    public void atrásCpp (View v){
        finish();
    }
}