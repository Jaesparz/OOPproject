package com.example.proyect;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

import modelo.CuentasPorCobrar;
import modelo.CuentasPorPagar;
import modelo.Persona;

public class ControladorCuentasPorPagar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cuentas_por_pagar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.tablacpp), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        cargarDatosPersonas();
        cargarDatosCpP();

    }
    private void cargarDatosCpP() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = CuentasPorPagar.crearDatosInicialesCpP(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES CPP GUARDADOS");
            //LEER LOS DATOS
        }
    }

    private void llenarTablaCpP() {
        // ArrayList<Empleado> lista =Empleado.obtenerEmpleados();
        ArrayList<CuentasPorPagar> lista = new ArrayList<>();
        ArrayList<Persona> lista2 = new ArrayList<>();
        try {
            lista = CuentasPorPagar.cargarCuentasporPagar(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            lista2 = Persona.cargarPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));

        } catch (Exception e) {
            Log.d("ProyectoPoo", "Error al cargar datos" + e.getMessage());
        }
        TableLayout tabla = findViewById(R.id.tablacpp);//recupera el tablelayout de la vista

        Log.d("ProyectoPoo", lista.toString());//muestra la lista en el log
        Log.d("ProyectoPoo", lista2.toString());
        cleanTableCpP(tabla);//limpiar la tabla
        for (CuentasPorPagar e : lista) {
            //Log.d("ProyectoPoo", e.toString());
            TableRow tr = new TableRow(this);//la fila para los datos de ese empleado

            TextView tvCodigo = new TextView(this);
            tvCodigo.setText(String.valueOf(e.getCodigo()));
            TextView tvEntidad = new TextView(this);
            tvEntidad.setText(e.getEntidad().getNombre());
            TextView tvValor = new TextView(this);
            tvValor.setText(String.valueOf(e.getValor()));
            TextView tvdescripcion = new TextView(this);
            tvdescripcion.setText(e.getDescripcion());
            TextView tvFechaPrestamo = new TextView(this);
            tvFechaPrestamo.setText(String.valueOf(e.getFechaPrestamo()));
            TextView tvCuota = new TextView(this);
            tvCuota.setText(String.valueOf(e.getCuota()));



            //agregar al tablerow
            tr.addView(tvCodigo);
            tr.addView(tvEntidad);
            tr.addView(tvValor);
            tr.addView(tvdescripcion);
            tr.addView(tvFechaPrestamo);
            tr.addView(tvCuota);
            //agregar al tableview
            tabla.addView(tr);

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        llenarTablaCpP();
        Log.d("ProyectoPoo", "En onResume");//muestra la lista en el log

    }

    private void cleanTableCpP(TableLayout table) {

        int childCount = table.getChildCount();

        // Remove all rows except the first one
        if (childCount > 1) {
            table.removeViews(1, childCount - 1);
        }
    }

    // controladorpersonas
    public void cargarDatosPersonas() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = Persona.crearDatosInicialesPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES PER GUARDADOS");
            //LEER LOS DATOS
        }
    }

    public void regresar (View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void registrarCpP(View v) {
        Intent intent = new Intent(this, registrarcpp.class);
        startActivity(intent);
    }




}