package com.example.proyect;

public class FinalizarIngreso {
}
