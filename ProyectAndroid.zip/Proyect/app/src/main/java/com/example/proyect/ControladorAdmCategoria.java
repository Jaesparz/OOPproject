package com.example.proyect;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.util.ArrayList;

import javax.xml.transform.OutputKeys;

import modelo.Categoria;
import modelo.CuentasPorCobrar;
import modelo.Persona;
import modelo.TipoCategoria;

public class ControladorAdmCategoria extends AppCompatActivity {
    private RegistrarCategoria registrarCategoria;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.cuentaporcobrar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.adm_categ), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        cargarDatosCat();
        cargarDatosPersonas();
        llenarTabla();


    }


    private void cargarDatosCat(){
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = Categoria.crearDatosIniciales(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES CAT GUARDADOS");
            //LEER LOS DATOS
        }
    }
    private void llenarTabla() {
        // ArrayList<Empleado> lista =Empleado.obtenerEmpleados();
        ArrayList<Categoria> lista = new ArrayList<>();
        ArrayList<Persona> lista2 = new ArrayList<>();
        try {
            lista = Categoria.cargarCategorias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            lista2 = Persona.cargarPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));

        } catch (Exception e) {
            Log.d("ProyectoPoo", "Error al cargar datos" + e.getMessage());
        }
        TableLayout tabla = findViewById(R.id.tabla_categorias);//recupera el tablelayout de la vista

        Log.d("ProyectoPoo", lista.toString());//muestra la lista en el log
        Log.d("ProyectoPoo", lista2.toString());
        cleanTable(tabla);//limpiar la tabla
        for (Categoria categoria : lista) {
            TableRow tr = new TableRow(this);

            TextView tvCodigo = new TextView(this);
            tvCodigo.setText(String.valueOf(categoria.getCodigo()));
            tr.addView(tvCodigo);

            TextView tvNombre = new TextView(this);
            tvNombre.setText(categoria.getNombre());
            tr.addView(tvNombre);

            TextView tvTipo = new TextView(this);
            tvTipo.setText(categoria.getTipo().toString());
            tr.addView(tvTipo);

            // Agregar más columnas según sea necesario

            tabla.addView(tr);
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        llenarTabla();
        Log.d("ProyectoPoo", "En onResume");//muestra la lista en el log

    }

    private void cleanTable(TableLayout table) {

        int childCount = table.getChildCount();

        // Remove all rows except the first one
        if (childCount > 1) {
            table.removeViews(1, childCount - 1);
        }
    }

    public void cargarDatosPersonas() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = Persona.crearDatosInicialesPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES PER GUARDADOS");
            //LEER LOS DATOS
        }
    }


    public void RegistrarCategoria(View v) {
        Intent intent = new Intent(this, RegistrarCategoria.class);
        startActivity(intent);

    }
    public void menuPrincipal (View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}