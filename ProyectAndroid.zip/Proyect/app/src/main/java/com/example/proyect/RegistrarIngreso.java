package com.example.proyect;

public class RegistrarIngreso {
}
