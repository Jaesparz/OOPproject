package com.example.proyect;

import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import modelo.CuentasPorCobrar;
import modelo.Persona;

public class registrarcpc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registrarcpc);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.registrarcpc), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private EditText et1cpc, et2cpc, et3cpc, et4cpc, et5cpc, et6cpc;
    private Button button11, button12;

    public void guardar(View v){
        et1cpc = findViewById(R.id.et1cpc);
        et2cpc = findViewById(R.id.et2cpc);
        et3cpc = findViewById(R.id.et3cpc);
        et4cpc = findViewById(R.id.et4cpc);
        et5cpc = findViewById(R.id.et5cpc);
        et6cpc = findViewById(R.id.et6cpc);
        String deudor = et1cpc.getText().toString();
        String cantidad= et2cpc.getText().toString();
        String descripcion = et3cpc.getText().toString();
        String fechaPrestamo = et4cpc.getText().toString();
        String cuota = et5cpc.getText().toString();
        String fechaInicioPago = et6cpc.getText().toString();
        ArrayList<Persona> personas= Persona.cargarPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        for (Persona p : personas) {
            if (p.getRucId().equals(deudor)) {
                registrarPrestamo(p, Double.parseDouble(cantidad), descripcion, LocalDate.parse(fechaPrestamo), Double.parseDouble(cuota), LocalDate.parse(fechaInicioPago), LocalDate.parse(fechaInicioPago), p.getRucId());
                Toast.makeText(getApplicationContext(),"Prestamo registrado", Toast.LENGTH_SHORT).show();
                finish();
                return;
            } else{
                Toast.makeText(getApplicationContext(),"Persona no encontrada", Toast.LENGTH_SHORT).show();
                finish();
                return;

            }
        }
    }

    public void registrarPrestamo(Persona deudor, double valor, String descripcion, LocalDate fechaPrestamo, double cuota, LocalDate fechaInicioPago, LocalDate fechaFinPago, String cedula) {
        ArrayList<CuentasPorCobrar> cuentasPorCobrar = CuentasPorCobrar.cargarCuentasporCobrar(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        cuentasPorCobrar.add(new CuentasPorCobrar(deudor, valor, descripcion, fechaPrestamo, cuota, fechaInicioPago, fechaFinPago, cedula));
        File f = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), CuentasPorCobrar.nomArchivo);
        //se escribe la lista serializada
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            //os.writeObject(personas);
            os.writeObject(cuentasPorCobrar);

        } catch (IOException e) {
            //quizas lanzar una excepcion personalizada
            //throw new Exception(e.getMessage());
            System.out.println("Error en la serealización");
        }


    }

    public void atrás (View v){
        finish();
    }
}