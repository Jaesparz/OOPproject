package com.example.proyect;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.Categoria;

public class RegistrarCategoria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_anadir_categoria);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.et_category_name), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private EditText et1categoria ;
    private Button button1, button2;

    public void guardar(View v){
        et1categoria = findViewById(R.id.et_category_name);

        String nombreCategoria = et1categoria.getText().toString();

        // Aquí puedes agregar la lógica para guardar la categoría en tu base de datos o archivo
        // Por ejemplo:
        ArrayList<Categoria> categorias = Categoria.cargarCategorias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        categorias.add(new Categoria(nombreCategoria, Categoria.getTipo()));
        File f = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), Categoria.nomArchivo);
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            os.writeObject(categorias);
        } catch (IOException e) {
            System.out.println("Error en la serealización");
        }
        Toast.makeText(getApplicationContext(),"Categoría registrada", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void atras (View v){
        finish();
    }
}
