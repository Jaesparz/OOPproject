
package modelo;

import android.os.Build;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Persona extends Entidad implements Serializable {
    public static final String nomArchivo = "personas.dat";


    /**
     * @param rucId representa la cedula o ruc en formato String
     * @param nombre representa el nombre  en formato String
     * @param telefono representa el telefono en formato String
     * @param email representa la direccion en formato String
     *
     */
    public Persona(String rucId, String nombre, String telefono, String email) {
        super(rucId, nombre, telefono, email);
    }


    /**
     * @return retorna un string
     */
    @Override
    public String toString(){
        return String.format("%-8d%-15s%-20s%-20s%-20s%-12s",
                super.getCodigo(), super.getFechaRegistro(), super.getRucId(), super.getNombre(), super.getEmail(),super.getOtrosDatos());
    }

    public static boolean crearDatosInicialesPersonas(File directorio) throws Exception{
        ArrayList<Persona> personas = new ArrayList<>();
        boolean guardado = false;

        // Inicializar personas
        personas.add(new Persona("0102030405", "Pedro López", "0998765432", "pedro@gmail.com"));
        personas.add(new Persona("0102030406", "Carlos Murillo", "0998765433", "carlos@gmail.com"));
        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if (! f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                os.writeObject(personas);
                //os.writeObject(cuentasPorCobrar);
                guardado = true;
            } catch (IOException e) {
                //quizas lanzar una excepcion personalizada
                //throw new Exception(e.getMessage());
                System.out.println("Error en la serealización");
            }
        }else guardado = true;//si existe no hace nada
        return guardado;
    }

    //lee el archivo donde se encuentran los datos
    public static ArrayList<Persona> cargarPersonas(File directorio){
        ArrayList<Persona> lista = new ArrayList<>();

        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if ( f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<Persona>) is.readObject();

            } catch (Exception e) {
                //quizas lanzar una excepcion personalizada
                new Exception(e.getMessage());
                System.out.println("Error en la deserialización");
            }
        }
        return lista;
    }


}


