package modelo;


import java.io.Serializable;

public class Banco extends Entidad implements Serializable {
    private String nombreOficialCredito;
    private String telefonoOficialCredito;

    /**
     * @param rucId representa la cedula en formato String
     * @param nombre representa el nombre  en formato String
     * @param telefono representa el telefono en formato String
     * @param email representa la direccion en formato String
     * @param nombreOficialCredito representa el nombre de un oficial de credito en formato String
     * @param telefonoOficialCredito representa el telefono de un oficial de credito en formato String
     *
     */
    public Banco(String rucId, String nombre, String telefono, String email, String nombreOficialCredito, String telefonoOficialCredito) {
        super(rucId, nombre, telefono, email);
        this.nombreOficialCredito = nombreOficialCredito;
        this.telefonoOficialCredito = telefonoOficialCredito;
    }

    /**
     * @return retorna un string
     */
    @Override
    public String getOtrosDatos() {
        return "Oficial: "+this.getNombreOficialCredito()+"   Telf: "+this.getTelefonoOficialCredito() ;
    }

    /**
     * @return nombreOficialCredito representa el nombre de un oficial de credito en formato String
     */

    public String getNombreOficialCredito() {
        return nombreOficialCredito;
    }

    /**
     * @return telefonoOficialCredito representa el telefono de un oficial de credito en formato String
     */

    public String getTelefonoOficialCredito() {
        return telefonoOficialCredito;
    }

    /**
     * @return retorna un string
     */

    @Override
    public String toString(){
        return String.format("%-8d%-15s%-20s%-25s%-30s%-12s",
                super.getCodigo(), super.getFechaRegistro(), super.getRucId(), super.getNombre(), super.getEmail(),this.getOtrosDatos());
    }
}