package modelo;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Jair Palaguachi
 * Clase CuentasPorPagar con sus atributos y métodos correspondientes
 */
public class CuentasPorPagar extends Cuentas  implements Serializable {
    private String RucId;
    private double interes;
    public static final String nomArchivo = "cuentasporpagar.dat";

    /**
     * @return RucId string que representa una cedula o ruc
     */
    public String getRucId() {
        return RucId;
    }

    /**
     * @return interes double que representa un interes
     */
    public double getInteres() {
        return interes;
    }

    /**
     * @param  RucId string que representa una cedula o ruc
     */
    public void setRucId(String RucId) {
        this.RucId = RucId;
    }

    /**
     * @param  interes double que representa un interes
     */
    public void setInteres(double interes) {
        this.interes = interes;
    }

    /**
     * @param entidad representa una instancia de la Clase Entidad
     * @param valor representa el valor en double
     * @param descripcion representa una instancia de la entidad Categoria
     * @param fechaPrestamo representa la fecha de prestamo
     * @param cuota representa la cuota en double
     * @param fechaInicioPago representa la fecha de inicio del pago
     * @param fechaFinPago representa la fecha de fin del pago
     * @param RucId representa el ruc o cedula en formato string
     * @param interes representa el interes en formato double
     */
    public CuentasPorPagar(Entidad entidad, double valor, String descripcion, LocalDate fechaPrestamo, double cuota, LocalDate fechaInicioPago, LocalDate fechaFinPago,String RucId,double interes) {

        super(entidad, valor, descripcion, fechaPrestamo, cuota, fechaInicioPago, fechaFinPago);
        this.RucId=RucId;
        this.interes=interes;
    }


    /**
     * @return retorna un string
     */
    @Override
    public String toString() {
        return "CuentasPorPagar{ codigo= " + super.getCodigo() + " "+
                "entidad='" + super.getEntidad().getNombre() + '\'' +
                ", valor='" + super.getValor() + '\'' +
                ", descripcion='" + super.getDescripcion() + '\'' +
                ", fechaPresamo='" + super.getFechaPrestamo() + '\'' +
                ", cuota='" + super.getCuota() + '\'' +
                ", fechaInicio='" + super.getFechaInicioPago() + '\'' +
                ", fechaFin='" + super.getFechaFinPago() + '\'' +
                ", RucId='" + this.getRucId() + '\'' +
                ", interes='" + this.getInteres() + '\'' +
                '}';
    }

    //lee el archivo donde se encuentran los datos
    public static ArrayList<CuentasPorPagar> cargarCuentasporPagar(File directorio){
        ArrayList<CuentasPorPagar> lista = new ArrayList<>();

        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if ( f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<CuentasPorPagar>) is.readObject();

            } catch (Exception e) {
                //quizas lanzar una excepcion personalizada
                new Exception(e.getMessage());
                System.out.println("Error en la deserialización");
            }
        }
        return lista;
    }

    /**
     *
     * @param directorio directorio en android donde se guardará el archivo
     * @return true si se pudo crear el archivo o ya existe.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static boolean crearDatosInicialesCpP(File directorio) {
        ArrayList<CuentasPorPagar> cuentasPorPagar = new ArrayList<>();
        ArrayList<Persona> personas = Persona.cargarPersonas(directorio);
        boolean guardado = false;


        // Inicializar cuentas por cobrar
        //personas.add(new Persona("0102030405", "Pedro López", "0998765432", "pedro@gmail.com"));


        cuentasPorPagar.add(new CuentasPorPagar(personas.get(1), 15000, "Préstamo para auto", LocalDate.of(2024, 2, 2), 600, LocalDate.of(2024, 3, 1), LocalDate.of(2025, 2, 1),"0102030406", 5.0));


        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if (! f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                //os.writeObject(personas);
                os.writeObject(cuentasPorPagar);
                guardado = true;
            } catch (IOException e) {
                //quizas lanzar una excepcion personalizada
                //throw new Exception(e.getMessage());
                System.out.println("Error en la serealización");
            }
        }else guardado = true;//si existe no hace nada
        return guardado;
    }

}

