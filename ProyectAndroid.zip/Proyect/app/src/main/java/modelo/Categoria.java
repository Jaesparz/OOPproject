package modelo;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Josue Esparza
 * //Clase Categoria con sus atributos y métodos correspondientes
 */
public class Categoria {
    public static final String nomArchivo = "Categorias.dat";
    private static int codigoCounter = 1;
    private int codigo;
    private String nombre;
    private static TipoCategoria tipo;

    /**
     * @param nombre String que identifica el nombre de una categoria
     * @param tipo String que identifica el tipo de una categoria
     *
     */
    public Categoria(String nombre, TipoCategoria tipo) {
        this.codigo = codigoCounter++;
        this.nombre = nombre;
        Categoria.tipo = tipo;
    }

    /**
     * @return codigo int que representa el codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @return nombre String que representa el nombre
     */

    public String getNombre() {
        return nombre;
    }

    /**
     * @return tipo instancia de la entidad TipoCategoria
     */


    public static TipoCategoria getTipo() {
        return tipo;
    }

    /**
     * @param nombre String que identifica el nombre de una categoria
     *
     */

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return retorna un string
     */
    @Override
    public String toString(){
        return "Categoria [Nombre=" + this.nombre + ", Tipo=" + this.tipo +"]";
    }


    //lee el archivo donde se encuentran los datos
    public static ArrayList<Categoria> cargarCategorias(File directorio){
        ArrayList<Categoria> lista = new ArrayList<>();

        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if ( f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<Categoria>) is.readObject();

            } catch (Exception e) {
                //quizas lanzar una excepcion personalizada
                new Exception(e.getMessage());
                System.out.println("Error en la deserialización");
            }
        }
        return lista;
    }


    /**
     *
     * @param directorio directorio en android donde se guardará el archivo
     * @return true si se pudo crear el archivo o ya existe.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static boolean crearDatosIniciales(File directorio) {
        ArrayList<Categoria> categorias = new ArrayList<>();
        ArrayList<Persona> personas = Persona.cargarPersonas(directorio);
        boolean guardado = false;


        // Inicializar categorias



        categorias.add(new Categoria("Salario", TipoCategoria.INGRESO));
        categorias.add(new Categoria("Alquiler", TipoCategoria.INGRESO));
        categorias.add(new Categoria("Comida", TipoCategoria.GASTO));
        categorias.add(new Categoria("Transporte", TipoCategoria.GASTO));


        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if (! f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                //os.writeObject(personas);
                os.writeObject(categorias);
                guardado = true;
            } catch (IOException e) {
                //quizas lanzar una excepcion personalizada
                //throw new Exception(e.getMessage());
                System.out.println("Error en la serealización");
            }
        }else guardado = true;//si existe no hace nada
        return guardado;
    }

}

