package com.example.proyect;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

import modelo.Banco;
import modelo.CuentaBancaria;
import modelo.CuentasPorPagar;
import modelo.Persona;

public class ControladorCuentaBancaria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cuenta_bancaria);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.admcb), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        cargarDatosCB();
        cargarDatosBancos();


    }

    private void cargarDatosCB() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = CuentaBancaria.crearDatosInicialesCB(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES CB GUARDADOS");
            //LEER LOS DATOS
        }
    }

    private void llenarTablaCB() {

        ArrayList<CuentaBancaria> lista = new ArrayList<>();
        ArrayList<Banco> lista2 = new ArrayList<>();
        try {
            lista = CuentaBancaria.cargarCuentasBancarias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            lista2 = Banco.cargarBancos(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));

        } catch (Exception e) {
            Log.d("ProyectoPoo", "Error al cargar datos" + e.getMessage());
        }
        TableLayout tabla = findViewById(R.id.tablacb);//recupera el tablelayout de la vista

        Log.d("ProyectoPoo", lista.toString());//muestra la lista en el log
        Log.d("ProyectoPoo", lista2.toString());
        cleanTableCB(tabla);//limpiar la tabla
        for (CuentaBancaria e : lista) {
            //Log.d("ProyectoPoo", e.toString());
            TableRow tr = new TableRow(this);

            TextView tvCodigo = new TextView(this);
            tvCodigo.setText(String.valueOf(e.getCodigo()));
            TextView tvEntidad = new TextView(this);
            tvEntidad.setText(e.getBanco().getNombre());
            TextView tvNumero = new TextView(this);
            tvNumero.setText(String.valueOf(e.getNumero()));
            TextView tvTipo = new TextView(this);
            tvTipo.setText(String.valueOf(e.getTipo()));
            TextView tvSaldo = new TextView(this);
            tvSaldo.setText(String.valueOf(e.getSaldo()));
            TextView tvFechaApertura = new TextView(this);
            tvFechaApertura.setText(String.valueOf(e.getFechaApertura()));
            TextView tvFechaCierre = new TextView(this);
            tvFechaCierre.setText(String.valueOf(e.getFechaCierre()));



            //agregar al tablerow
            tr.addView(tvCodigo);
            tr.addView(tvEntidad);
            tr.addView(tvNumero);
            tr.addView(tvTipo);
            tr.addView(tvSaldo);
            tr.addView(tvFechaApertura);
            tr.addView(tvFechaCierre);
            //agregar al tableview
            tabla.addView(tr);

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        llenarTablaCB();
        Log.d("ProyectoPoo", "En onResume");//muestra la lista en el log

    }

    private void cleanTableCB(TableLayout table) {

        int childCount = table.getChildCount();

        // Remove all rows except the first one
        if (childCount > 1) {
            table.removeViews(1, childCount - 1);
        }
    }





    // controladorbancos
    public void cargarDatosBancos() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = Banco.crearDatosInicialesBancos(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES BAN GUARDADOS");
            //LEER LOS DATOS
        }
    }

    public void regresarCB (View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
    public void agregarCuentaBancaria (View v){
        Intent intent = new Intent(this, agregarcuentabancaria.class);
        startActivity(intent);
    }

    public void eliminarCB (View v){
        Intent intent = new Intent(this, eliminarcuentabancaria.class);
        startActivity(intent);

    }

    public void cerrarCuentaBancaria (View v){
        Intent intent = new Intent(this, cerrarcuentabancaria.class);
        startActivity(intent);
    }



}