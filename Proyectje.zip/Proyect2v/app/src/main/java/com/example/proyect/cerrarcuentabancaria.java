package com.example.proyect;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import modelo.CuentaBancaria;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

public class cerrarcuentabancaria extends AppCompatActivity {

    private EditText et1CCB, et2CCB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cerrarcuentabancaria);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.cerrarCB), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void regresarCB (View v) {
        finish();
    }


    public void cerrarCuentaBancaria (View v) {
        et1CCB = findViewById(R.id.et1CCB);
        et2CCB = findViewById(R.id.et2CCB);
        String codigo = et1CCB.getText().toString();
        String fecha = et2CCB.getText().toString();
        if (codigo.isEmpty() || fecha.isEmpty()) {
            Toast.makeText(getApplicationContext(),"Ingrese todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<CuentaBancaria> cuentasBancarias = CuentaBancaria.cargarCuentasBancarias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        boolean encontrado = false;
        for (CuentaBancaria cuenta : cuentasBancarias) {
            if (cuenta.getCodigo() == Integer.parseInt(codigo)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (LocalDate.parse(fecha).isAfter(cuenta.getFechaApertura())) {
                        cuenta.setFechaCierre(LocalDate.parse(fecha));
                        encontrado = true;
                        File f = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), CuentaBancaria.nomArchivo);
                        //se escribe la lista serializada
                        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                            //os.writeObject(personas);
                            os.writeObject(cuentasBancarias);

                        } catch (IOException e) {
                            //quizas lanzar una excepcion personalizada
                            //throw new Exception(e.getMessage());
                            System.out.println("Error en la serealización");
                        }
                        Toast.makeText(getApplicationContext(),"Cuenta Bancaria cerrada", Toast.LENGTH_SHORT).show();
                        finish();
                        return;

                    } else {
                        Toast.makeText(getApplicationContext(),"Fecha de cierre inválida", Toast.LENGTH_SHORT).show();


                    }
                }
            }
        }

        Toast.makeText(getApplicationContext(), "Cuenta Bancaria no encontrada", Toast.LENGTH_SHORT).show();
        finish();


    }

}