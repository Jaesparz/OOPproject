package com.example.proyect;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import modelo.Banco;
import modelo.CuentaBancaria;
import modelo.CuentasPorCobrar;
import modelo.Persona;
import modelo.TipoCuenta;


public class agregarcuentabancaria extends AppCompatActivity {

    private EditText et1cba, et2cba, et3cba, et4cba, et5cba, et6cba;
    private Button button5, button6;
    private Spinner spinner1cba;
    private String[] tipo={"AHORRO","CORRIENTE"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agregarcuentabancaria);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.agregarCB), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et1cba = findViewById(R.id.et1cba);
        et2cba = findViewById(R.id.et2cba);
        et3cba = findViewById(R.id.et3cba);
        et4cba = findViewById(R.id.et4cba);
        et5cba = findViewById(R.id.et5cba);
        et6cba = findViewById(R.id.et6cba);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        spinner1cba = findViewById(R.id.spinner1cba);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tipo);
        spinner1cba.setAdapter(adapter);

    }

    public void guardarCB (View v){
        String entidad = et1cba.getText().toString();
        String numero = et2cba.getText().toString();
        String tipo = spinner1cba.getSelectedItem().toString();
        String fechaApertura = et3cba.getText().toString();
        String saldo = et4cba.getText().toString();
        String interes = et5cba.getText().toString();
        String fechaCierre = et6cba.getText().toString();
        //String fechaCierre = fechaCierre.isEmpty() ? null : LocalDate.parse(fechaCierre);
        ArrayList<Banco> bancos = Banco.cargarBancos(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        for (Banco b : bancos) {
            if (b.getRucId().equals(entidad)) {
                if (fechaCierre.isEmpty()) {
                    registrarCuentaBancaria(b, numero, TipoCuenta.valueOf(tipo), LocalDate.parse(fechaApertura), Double.parseDouble(saldo), Double.parseDouble(interes), null);
                    Toast.makeText(getApplicationContext(),"Cuenta Bancaria registrado", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                registrarCuentaBancaria(b, numero, TipoCuenta.valueOf(tipo), LocalDate.parse(fechaApertura), Double.parseDouble(saldo), Double.parseDouble(interes), LocalDate.parse(fechaCierre));
                Toast.makeText(getApplicationContext(),"Cuenta Bancaria registrado", Toast.LENGTH_SHORT).show();
                finish();
                return;

            }
        }
        Toast.makeText(getApplicationContext(),"Banco no encontrado", Toast.LENGTH_SHORT).show();
        finish();


    }

    // Métodos para administrar cuentas bancarias
    public void registrarCuentaBancaria(Banco banco, String numero, TipoCuenta tipo, LocalDate fechaApertura, double saldo, double interesMensual, LocalDate fechaCierre) {
        ArrayList<CuentaBancaria> cuentasBancarias = CuentaBancaria.cargarCuentasBancarias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        cuentasBancarias.add(new CuentaBancaria(banco, numero, tipo, fechaApertura, saldo, interesMensual,fechaCierre));
        File f = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), CuentaBancaria.nomArchivo);
        //se escribe la lista serializada
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            //os.writeObject(personas);
            os.writeObject(cuentasBancarias);

        } catch (IOException e) {
            //quizas lanzar una excepcion personalizada
            //throw new Exception(e.getMessage());
            System.out.println("Error en la serealización");
        }
    }

    public void atrásCB (View v){
        finish();
    }








}