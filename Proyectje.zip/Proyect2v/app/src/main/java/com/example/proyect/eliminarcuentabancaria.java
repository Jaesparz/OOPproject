package com.example.proyect;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.CuentaBancaria;

public class eliminarcuentabancaria extends AppCompatActivity {
    private EditText et1ECBA;
    private static final int REQUEST_CODE_VALIDACION = 1;
    private int codigoInt; // Store codigoInt as a member variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_eliminarcuentabancaria);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.ecba), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void regresarECBA (View v){
        finish();
    }

    public void eliminarCuentaBancaria (View v) {
        et1ECBA = findViewById(R.id.et1ECBA);
        String codigo = et1ECBA.getText().toString();
        if (codigo.isEmpty()) {
            Toast.makeText(getApplicationContext(),"Ingrese un código", Toast.LENGTH_SHORT).show();
            return;
        }

        codigoInt = Integer.parseInt(codigo); // Store codigoInt

        Intent intent = new Intent(this, Validacion.class);
        startActivityForResult(intent, REQUEST_CODE_VALIDACION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_VALIDACION) {
            if (resultCode == RESULT_OK) {
                ArrayList<CuentaBancaria> cuentasBancarias = CuentaBancaria.cargarCuentasBancarias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
                for (CuentaBancaria cuenta : cuentasBancarias) {
                    if (cuenta.getCodigo() == codigoInt) {
                        eliminarCuentaBancaria(codigoInt);
                        Toast.makeText(getApplicationContext(),"Cuenta Bancaria eliminada", Toast.LENGTH_SHORT).show();
                        finish();
                        return;
                    }
                }
                Toast.makeText(getApplicationContext(),"Cuenta Bancaria no encontrada", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(getApplicationContext(),"Eliminación cancelada", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void eliminarCuentaBancaria(int codigo) {
        ArrayList<CuentaBancaria> cuentasBancarias = CuentaBancaria.cargarCuentasBancarias(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
        cuentasBancarias.removeIf(cuenta -> cuenta.getCodigo() == codigo);
        File f = new File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), CuentaBancaria.nomArchivo);
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
            os.writeObject(cuentasBancarias);
        } catch (IOException e) {
            System.out.println("Error en la serialización");
        }
    }
}