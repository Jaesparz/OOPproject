package com.example.proyect;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

import modelo.CuentasPorCobrar;
import modelo.Persona;

public class ControladorCuentasporCobrar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.cuentaporcobrar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.admcpc), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        cargarDatosCpC();
        cargarDatosPersonas();
        //llenarTabla();


    }


    private void cargarDatosCpC() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = CuentasPorCobrar.crearDatosIniciales(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES CPC GUARDADOS");
            //LEER LOS DATOS
        }
    }


    private void llenarTabla() {
        // ArrayList<Empleado> lista =Empleado.obtenerEmpleados();
        ArrayList<CuentasPorCobrar> lista = new ArrayList<>();
        ArrayList<Persona> lista2 = new ArrayList<>();
        try {
            lista = CuentasPorCobrar.cargarCuentasporCobrar(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            lista2 = Persona.cargarPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));

        } catch (Exception e) {
            Log.d("ProyectoPoo", "Error al cargar datos" + e.getMessage());
        }
        TableLayout tabla = findViewById(R.id.tablaCpC);//recupera el tablelayout de la vista

        Log.d("ProyectoPoo", lista.toString());//muestra la lista en el log
        Log.d("ProyectoPoo", lista2.toString());
        cleanTable(tabla);//limpiar la tabla
        for (CuentasPorCobrar e : lista) {
            //Log.d("ProyectoPoo", e.toString());
            TableRow tr = new TableRow(this);//la fila para los datos de ese empleado

            TextView tvCodigo = new TextView(this);//textview para el nombre
            tvCodigo.setText(String.valueOf(e.getCodigo())); //se asigna el nombre del empleado en el textview
            TextView tvEntidad = new TextView(this);//textview para el departamento
            tvEntidad.setText(e.getEntidad().getNombre());//se asigna el departamento del empleado en el textview
            TextView tvValor = new TextView(this);//textview para el departamento
            tvValor.setText(String.valueOf(e.getValor()));//se asigna el departamento del empleado en el textview
            TextView tvdescripcion = new TextView(this);//textview para el departamento
            tvdescripcion.setText(e.getDescripcion());//se asigna el departamento del empleado en el textview
            TextView tvFechaPrestamo = new TextView(this);//textview para el departamento
            tvFechaPrestamo.setText(String.valueOf(e.getFechaPrestamo()));
            TextView tvCuota = new TextView(this);//textview para el departamento
            tvCuota.setText(String.valueOf(e.getCuota()));


            //agregar al tablerow
            tr.addView(tvCodigo);
            tr.addView(tvEntidad);
            tr.addView(tvValor);
            tr.addView(tvdescripcion);
            tr.addView(tvFechaPrestamo);
            tr.addView(tvCuota);
            //agregar al tableview
            tabla.addView(tr);

        }
    }


    @Override
    public void onResume() {
        super.onResume();
        llenarTabla();
        Log.d("ProyectoPoo", "En onResume");//muestra la lista en el log

    }

    private void cleanTable(TableLayout table) {

        int childCount = table.getChildCount();

        // Remove all rows except the first one
        if (childCount > 1) {
            table.removeViews(1, childCount - 1);
        }
    }

    // controladorpersonas
    public void cargarDatosPersonas() {
        boolean guardado = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                guardado = Persona.crearDatosInicialesPersonas(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
            }

        } catch (Exception e) {
            guardado = false;
            Log.d("ProyectoPoo", "Error al crear los datos iniciales" + e.getMessage());
        }
        if (guardado) {
            Log.d("ProyectoPoo", "DATOS INICIALES PER GUARDADOS");
            //LEER LOS DATOS
        }
    }


    public void registrarCpC(View v) {
        Intent intent = new Intent(this, registrarcpc.class);
        startActivity(intent);

    }
    public void menuPrincipal (View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}