package modelo;

import java.io.Serializable;

/**
 *
 * @author Jair Palaguachi
 * Enumerate TipoCuenta util para identificar el tipo de cuenta
 */
public enum TipoCuenta implements Serializable {
    AHORRO,
    CORRIENTE
}
