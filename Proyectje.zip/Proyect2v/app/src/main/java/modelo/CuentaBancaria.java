package modelo;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Jair Palaguachi
 * Clase CuentaBancaria con sus atributos y métodos correspondientes
 */
public class CuentaBancaria implements Serializable {

    private static int codigoCounter = 1;
    private int codigo;
    private Banco banco;
    private String numero;
    private TipoCuenta tipo;
    private LocalDate fechaApertura;
    private double saldo;
    private double interesMensual;
    private LocalDate fechaCierre;
    public static final String nomArchivo = "cuentasbancaria2.dat";

    /**
     * @param banco representa una instancia de la entidad Banco
     * @param numero representa el numero de cuenta en formato String
     * @param tipo representa una instancia de la entidad TipoCuenta
     * @param fechaApertura representa la fecha de apertura
     * @param saldo representa el saldo en double
     * @param interesMensual representa el interes mensual en formato double
     * @param fechaCierre representa la fecha de cierre
     *
     */
    public CuentaBancaria(Banco banco, String numero, TipoCuenta tipo, LocalDate fechaApertura, double saldo, double interesMensual,LocalDate fechaCierre) {
        this.codigo = codigoCounter++;
        this.banco = banco;
        this.numero = numero;
        this.tipo = tipo;
        this.fechaApertura = fechaApertura;
        this.saldo = saldo;
        this.interesMensual = interesMensual;
        this.fechaCierre=fechaCierre;
    }

    /**
     * @return codigo int que representa un codigo
     */

    public int getCodigo() {
        return codigo;
    }

    /**
     * @return banco que representa una instancia de la entidad Banco
     */
    public Banco getBanco() {
        return banco;
    }

    /**
     * @return numero string que representa un numero
     */

    public String getNumero() {
        return numero;
    }

    /**
     * @return tipo que representa una instancia de la entidad TipoCuenta
     */

    public TipoCuenta getTipo() {
        return tipo;
    }

    /**
     * @return fechaApertura representa la fecha de apertura
     */

    public LocalDate getFechaApertura() {
        return fechaApertura;
    }

    /**
     * @return saldo representa el saldo en double
     */

    public double getSaldo() {
        return saldo;
    }

    /**
     * @return interesMensual representa el interes mensual en formato double
     */

    public double getInteresMensual() {
        return interesMensual;
    }

    /**
     * @return fechaCierre representa la fecha de cierre
     */

    public LocalDate getFechaCierre() {
        return fechaCierre;
    }

    /**
     * @param codigo int que representa un codigo
     *
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @param banco representa una instancia de la entidad Banco
     */
    public void setBanco(Banco banco) {
        this.banco = banco;
    }

    /**
     * @param numero representa el numero de cuenta en formato String
     */

    public void setNumero(String numero) {
        this.numero = numero;
    }

    /**
     * @param tipo representa una instancia de la entidad TipoCuenta
     */
    public void setTipo(TipoCuenta tipo) {
        this.tipo = tipo;
    }

    /**
     * @param fechaApertura representa la fecha de apertura
     */
    public void setFechaApertura(LocalDate fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    /**
     * @param saldo representa el saldo en double
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * @param interesMensual representa el interes mensual en formato double
     */
    public void setInteresMensual(double interesMensual) {
        this.interesMensual = interesMensual;
    }

    /**
     * @param fechaCierre representa la fecha de cierre
     *
     */
    public void setFechaCierre(LocalDate fechaCierre) {
        this.fechaCierre = fechaCierre;
    }


    /**
     * @return retorna un string
     * */

    @Override
    public String toString() {
        return "CuentasBancarias{ codigo= " + this.getCodigo() + " "+
                "Banco='" + this.getBanco().getNombre() + '\'' +
                ", numero='" + this.getNumero() + '\'' +
                ", tipo='" + this.getTipo() + '\'' +
                ", fechaApertura='" + this.getFechaApertura() + '\'' +
                ", saldo='" + this.getSaldo() + '\'' +
                ", interes='" + this.getInteresMensual() + '\'' +
                ", fechaCierre='" + this.getFechaCierre() + '\'' +
                '}';
    }

    //lee el archivo donde se encuentran los datos
    public static ArrayList<CuentaBancaria> cargarCuentasBancarias(File directorio){
        ArrayList<CuentaBancaria> lista = new ArrayList<>();

        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if ( f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<CuentaBancaria>) is.readObject();

            } catch (Exception e) {
                //quizas lanzar una excepcion personalizada
                new Exception(e.getMessage());
                System.out.println("Error en la deserialización");
                e.printStackTrace();
                Log.e("ProyectoPoo", "Error en la deserialización: " + e.getMessage(), e);

            }
        }
        return lista;
    }

    /**
     *
     * @param directorio directorio en android donde se guardará el archivo
     * @return true si se pudo crear el archivo o ya existe.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static boolean crearDatosInicialesCB(File directorio) {
        ArrayList<CuentaBancaria> cuentasBancarias = new ArrayList<>();
        ArrayList<Banco> bancos = Banco.cargarBancos(directorio);
        boolean guardado = false;


        cuentasBancarias.add(new CuentaBancaria(bancos.get(0), "1034324", TipoCuenta.AHORRO, LocalDate.of(2024, 1, 1), 600, 0.05,LocalDate.of(2025, 1, 1)));


        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if (! f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                //os.writeObject(personas);
                os.writeObject(cuentasBancarias);
                guardado = true;
            } catch (IOException e) {
                //quizas lanzar una excepcion personalizada
                //throw new Exception(e.getMessage());
                System.out.println("Error en la serealización");
            }
        }else guardado = true;//si existe no hace nada
        return guardado;
    }



}

