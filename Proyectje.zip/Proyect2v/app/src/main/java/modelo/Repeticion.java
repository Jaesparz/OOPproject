package modelo;

/**
 *
 * @author Jair Palaguachi
 * Enumerate Repeticion  util para identificar la repeticion
 */
public enum Repeticion {
    SINREPETICION,
    MES,

}