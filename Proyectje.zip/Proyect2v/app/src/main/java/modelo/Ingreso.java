package modelo;
import java.time.LocalDate;

public class Ingreso extends Transaccion{


    public Ingreso(LocalDate fechaInicio, Categoria categoria, double valor, String descripcion, LocalDate fechaFin, Repeticion repeticion){
        super(fechaInicio,categoria,valor,descripcion,fechaFin,repeticion);

    }



}
