package modelo;
import java.time.LocalDate;



public class Gasto extends Transaccion {


    public Gasto(LocalDate fechaInicio, Categoria categoria, double valor, String descripcion, LocalDate fechaFin, Repeticion repeticion){
        super(fechaInicio,categoria,valor,descripcion,fechaFin,repeticion);

    }



}