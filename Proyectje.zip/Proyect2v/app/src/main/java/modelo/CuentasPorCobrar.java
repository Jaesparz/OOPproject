package modelo;


import android.annotation.SuppressLint;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author Jair Palaguachi
 * Clase CuentasPorCobrar con sus atributos y métodos correspondientes
 */
public class CuentasPorCobrar extends Cuentas  implements Serializable {

    private String cedula;
    public static final String nomArchivo = "cuentasporcobrar2.dat";

    /**
     * @return cedula string que representa una cedula
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * @param cedula string que representa una cedula
     */

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }


    /**
     * @param entidad representa una instancia de la Clase Entidad
     * @param valor representa el valor en double
     * @param descripcion representa una instancia de la entidad Categoria
     * @param fechaPrestamo representa la fecha de prestamo
     * @param cuota representa la cuota en double
     * @param fechaInicioPago representa la fecha de inicio del pago
     * @param fechaFinPago representa la fecha de fin del pago
     * @param cedula representa la cedulaen formato String
     */
    public CuentasPorCobrar(Entidad entidad, double valor, String descripcion, LocalDate fechaPrestamo, double cuota, LocalDate fechaInicioPago, LocalDate fechaFinPago, String cedula) {

        super(entidad, valor, descripcion, fechaPrestamo, cuota, fechaInicioPago, fechaFinPago);
        this.cedula=cedula;
    }


    /**
     * @return retorna un string
     * */

    @Override
    public String toString() {
        return "CuentasPorCobrar{ codigo= " + super.getCodigo() + " "+
                "entidad='" + super.getEntidad().getNombre() + '\'' +
                ", valor='" + super.getValor() + '\'' +
                ", descripcion='" + super.getDescripcion() + '\'' +
                ", fechaPresamo='" + super.getFechaPrestamo() + '\'' +
                ", cuota='" + super.getCuota() + '\'' +
                ", fechaInicio='" + super.getFechaInicioPago() + '\'' +
                ", fechaFin='" + super.getFechaFinPago() + '\'' +
                ", cedula='" + this.getCedula() + '\'' +
                '}';
    }


    //lee el archivo donde se encuentran los datos
    public static ArrayList<CuentasPorCobrar> cargarCuentasporCobrar(File directorio){
        ArrayList<CuentasPorCobrar> lista = new ArrayList<>();

        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if ( f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<CuentasPorCobrar>) is.readObject();

            } catch (Exception e) {
                //quizas lanzar una excepcion personalizada
                new Exception(e.getMessage());
                System.out.println("Error en la deserialización");
            }
        }
        return lista;
    }


    /**
     *
     * @param directorio directorio en android donde se guardará el archivo
     * @return true si se pudo crear el archivo o ya existe.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static boolean crearDatosIniciales(File directorio) {
        ArrayList<CuentasPorCobrar> cuentasPorCobrar = new ArrayList<>();
        ArrayList<Persona> personas = Persona.cargarPersonas(directorio);
        boolean guardado = false;


        // Inicializar cuentas por cobrar
        //personas.add(new Persona("0102030405", "Pedro López", "0998765432", "pedro@gmail.com"));


        cuentasPorCobrar.add(new CuentasPorCobrar(personas.get(0), 500, "Préstamo a Pedro", LocalDate.of(2024, 2, 2), 50, LocalDate.of(2024, 3, 1), LocalDate.of(2024, 6, 1),"0102030405"));


        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if (! f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                //os.writeObject(personas);
                os.writeObject(cuentasPorCobrar);
                guardado = true;
            } catch (IOException e) {
                //quizas lanzar una excepcion personalizada
                //throw new Exception(e.getMessage());
                System.out.println("Error en la serealización");
            }
        }else guardado = true;//si existe no hace nada
        return guardado;
    }





}