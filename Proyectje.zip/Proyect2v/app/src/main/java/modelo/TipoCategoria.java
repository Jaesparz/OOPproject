package modelo;

/**
 *
 * @author Josue Esparza
 * Enumerate TipoCategoria util para identificar el tipo de categoria
 */
public enum TipoCategoria {
    INGRESO,
    GASTO
}
