package modelo;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Banco extends Entidad implements Serializable {
    private String nombreOficialCredito;
    private String telefonoOficialCredito;
    public static final String nomArchivo = "bancos.dat";

    /**
     * @param rucId representa la cedula en formato String
     * @param nombre representa el nombre  en formato String
     * @param telefono representa el telefono en formato String
     * @param email representa la direccion en formato String
     * @param nombreOficialCredito representa el nombre de un oficial de credito en formato String
     * @param telefonoOficialCredito representa el telefono de un oficial de credito en formato String
     *
     */
    public Banco(String rucId, String nombre, String telefono, String email, String nombreOficialCredito, String telefonoOficialCredito) {
        super(rucId, nombre, telefono, email);
        this.nombreOficialCredito = nombreOficialCredito;
        this.telefonoOficialCredito = telefonoOficialCredito;
    }

    /**
     * @return retorna un string
     */
    @Override
    public String getOtrosDatos() {
        return "Oficial: "+this.getNombreOficialCredito()+"   Telf: "+this.getTelefonoOficialCredito() ;
    }

    /**
     * @return nombreOficialCredito representa el nombre de un oficial de credito en formato String
     */

    public String getNombreOficialCredito() {
        return nombreOficialCredito;
    }

    /**
     * @return telefonoOficialCredito representa el telefono de un oficial de credito en formato String
     */

    public String getTelefonoOficialCredito() {
        return telefonoOficialCredito;
    }

    /**
     * @return retorna un string
     */

    @Override
    public String toString(){
        return String.format("%-8d%-15s%-20s%-25s%-30s%-12s",
                super.getCodigo(), super.getFechaRegistro(), super.getRucId(), super.getNombre(), super.getEmail(),this.getOtrosDatos());
    }

    public static boolean crearDatosInicialesBancos(File directorio) throws Exception{
        ArrayList<Banco> bancos = new ArrayList<>();
        boolean guardado = false;

        // Inicializar bancos
        bancos.add(new Banco("1790018230001", "Banco del Pacifico","0955567890" ,"contacto@bancopacifico.com", "Rosa C", "0991122334"));
        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if (! f.exists()) { //si no existe se crea la lista
            try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(f))) {
                os.writeObject(bancos);
                //os.writeObject(cuentasPorCobrar);
                guardado = true;
            } catch (IOException e) {
                //quizas lanzar una excepcion personalizada
                //throw new Exception(e.getMessage());
                System.out.println("Error en la serealización");
            }
        }else guardado = true;//si existe no hace nada
        return guardado;
    }

    //lee el archivo donde se encuentran los datos
    public static ArrayList<Banco> cargarBancos(File directorio){
        ArrayList<Banco> lista = new ArrayList<>();

        File f = new File(directorio, nomArchivo);
        //se escribe la lista serializada
        if ( f.exists()) { //si no existe se crea la lista
            try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(f))) {
                lista = (ArrayList<Banco>) is.readObject();

            } catch (Exception e) {
                //quizas lanzar una excepcion personalizada
                new Exception(e.getMessage());
                System.out.println("Error en la deserialización");
            }
        }
        return lista;
    }

}